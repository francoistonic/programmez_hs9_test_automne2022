namespace Shop;

public interface ISaveOrder
{
    public void Save(Order order);
}
