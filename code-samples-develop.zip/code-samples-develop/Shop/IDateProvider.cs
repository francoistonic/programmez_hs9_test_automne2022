namespace Shop;

public interface IDateProvider
{
    public DateTime Now();
}

