import {dataGenenator} from './dataGenerator'
import {
  checkThatContactMessageIsCorrectlySent,
  sendAContactMessage,
} from './owners_messages_management'

export const hotelApp = {
  dataGenenator,
  checkThatContactMessageIsCorrectlySent,
  sendAContactMessage,
}
